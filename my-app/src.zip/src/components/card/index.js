import Card from './card';



export default Card;

