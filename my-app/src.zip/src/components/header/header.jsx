import React from "react";

const Header = () => {
  return (
    <nav id="mainNav">
      <div className="Navbar">
        <h1>where in the world?</h1>
        <h1 className="NavDark">Dark Mood</h1>
      </div>
    </nav>
  );
};

export default Header;
